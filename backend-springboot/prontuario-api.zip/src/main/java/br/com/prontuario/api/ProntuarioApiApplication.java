package br.com.prontuario.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProntuarioApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProntuarioApiApplication.class, args);
	}

}
